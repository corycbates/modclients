#!/bin/bash

# Simple startup script for Render
npm install
node server.js
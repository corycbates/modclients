import { ClientList } from "@/components/clients/ClientList";

export default function ClientsPage() {
  return <ClientList />;
}
